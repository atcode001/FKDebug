rm -rf /data/local/tmp/FKLoader
